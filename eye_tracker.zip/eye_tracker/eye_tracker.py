import cv2
import numpy as np
import pyautogui

# PyAutoGUI Safety settings
pyautogui.FAILSAFE = False
screen_w, screen_h = pyautogui.size()

cam = cv2.VideoCapture(0)

prev_x, prev_y = 0, 0
smooth_factor = 0.25

print("Starting Eye Tracking Mouse... Press ESC to exit.")

while cam.isOpened():
    success, frame = cam.read()
    if not success:
        print("Camera feed error!")
        break

    frame = cv2.flip(frame, 1)  # Mirror image
    frame_h, frame_w, _ = frame.shape

    # Focus on Eye Region (Center upper portion of frame)
    roi_x1, roi_y1 = int(frame_w * 0.25), int(frame_h * 0.25)
    roi_x2, roi_y2 = int(frame_w * 0.75), int(frame_h * 0.65)
    
    roi = frame[roi_y1:roi_y2, roi_x1:roi_x2]
    gray_roi = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
    
    # Blur to remove noise
    blurred = cv2.GaussianBlur(gray_roi, (7, 7), 0)
    
    # Thresholding to isolate dark pupil area
    _, threshold = cv2.threshold(blurred, 40, 255, cv2.THRESH_BINARY_INV)

    # Find contours for pupil
    contours, _ = cv2.findContours(threshold, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    contours = sorted(contours, key=lambda x: cv2.contourArea(x), reverse=True)

    # Draw ROI Box
    cv2.rectangle(frame, (roi_x1, roi_y1), (roi_x2, roi_y2), (255, 0, 0), 2)

    if contours:
        cnt = contours[0]
        (x, y, w, h) = cv2.boundingRect(cnt)
        
        # Draw pupil box & center dot inside ROI
        cv2.rectangle(roi, (x, y), (x + w, y + h), (0, 255, 0), 2)
        center_x = x + int(w / 2)
        center_y = y + int(h / 2)
        cv2.circle(roi, (center_x, center_y), 4, (0, 0, 255), -1)

        # Map to screen size
        norm_x = center_x / (roi_x2 - roi_x1)
        norm_y = center_y / (roi_y2 - roi_y1)

        target_x = screen_w * norm_x
        target_y = screen_h * norm_y

        # Exponential Smoothing for Mouse Cursor
        curr_x = prev_x + (target_x - prev_x) * smooth_factor
        curr_y = prev_y + (target_y - prev_y) * smooth_factor

        pyautogui.moveTo(curr_x, curr_y)
        prev_x, prev_y = curr_x, curr_y

    cv2.imshow('Eye Tracking Mouse', frame)

    if cv2.waitKey(1) & 0xFF == 27:  # Press ESC to stop
        break

cam.release()
cv2.destroyAllWindows()